Name        Maxwell Lim
NetID       MRL180002
Project     Project 4
IDE         IntelliJ
Java        1.8