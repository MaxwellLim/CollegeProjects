public interface IDedObject
    {
        int getID();
        String printID();
    }
